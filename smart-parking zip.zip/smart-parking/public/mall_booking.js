import { auth, db } from "./firebase.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

import {
  collection,
  getDocs,
  doc,
  updateDoc,
  addDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

const slotBox = document.getElementById("slotContainer");
const countInfo = document.getElementById("countInfo");

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    window.location.href = "login.html";
    return;
  }
  loadSlots();
});

async function loadSlots() {
  const snap = await getDocs(collection(db, "mall_slots"));
  let available = 0;
  let occupied = 0;

  slotBox.innerHTML = "";

  snap.forEach((docSnap) => {
    const s = docSnap.data();
    if (s.status === "available") available++;
    else occupied++;

    const div = document.createElement("div");
    div.className = "slot-card " + s.status;

    div.innerHTML = `
      <h3>${s.slotId}</h3>
      <p>${s.status === "available" ? "$ 5/hr" : "Booked"}</p>
      <button class="select-btn" ${s.status !== "available" ? "disabled" : ""}>
        Select
      </button>
    `;

    div.querySelector("button").addEventListener("click", () => {
      confirmBooking(s.slotId);
    });

    slotBox.appendChild(div);
  });

  countInfo.innerHTML = `${available} Available • ${occupied} Occupied`;
}

async function confirmBooking(slotId) {
  const vehicle = prompt("Enter Vehicle Number:");
  if (!vehicle) return;

  await addDoc(collection(db, "mall_bookings"), {
    slotId,
    vehicle,
    time: serverTimestamp(),
  });

  await updateDoc(doc(db, "mall_slots", slotId), {
    status: "booked"
  });

  alert("Booking Confirmed!");
  loadSlots();
}
