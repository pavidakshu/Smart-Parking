import { auth, db } from "./firebase.js";
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import {
  collection,
  setDoc,
  doc,
  updateDoc,
  addDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

import { fetchSlots } from "./fetchSlots.js";

const DEFAULT_SLOTS = ["A1","A2","A3","A4","B1","B2","B3","B4"];

let currentUser = null;
let selectedSlotId = null;

// DOM
const userInfoEl = document.getElementById("userInfo");
const slotGrid = document.getElementById("slotGrid");
const selectedSlotText = document.getElementById("selectedSlotText");
const vehicleInput = document.getElementById("vehicleNumber");
const durationInput = document.getElementById("duration");
const confirmBookingBtn = document.getElementById("confirmBookingBtn");
const logoutBtn = document.getElementById("logoutBtn");

// auth state
onAuthStateChanged(auth, async (user) => {
  if (!user) {
    window.location.href = "login.html";
    return;
  }
  currentUser = user;
  userInfoEl.innerText = `Logged in as ${user.email}`;

  await ensureDefaultSlots();
  await loadSlots();
});

logoutBtn.addEventListener("click", () => {
  signOut(auth).then(() => {
    window.location.href = "login.html";
  });
});

confirmBookingBtn.addEventListener("click", () => {
  handleConfirmBooking();
});

async function ensureDefaultSlots() {
  const existing = await fetchSlots();
  if (existing.length > 0) return;

  const ops = DEFAULT_SLOTS.map((id) =>
    setDoc(doc(db, "parking_slots", id), {
      slotId: id,
      status: "available",
      createdAt: serverTimestamp()
    })
  );
  await Promise.all(ops);
}

async function loadSlots() {
  const list = await fetchSlots();
  slotGrid.innerHTML = "";

  list.forEach((s) => {
    const div = document.createElement("div");
    div.classList.add("slot");
    div.classList.add(s.status === "booked" ? "booked" : "available");
    div.innerText = s.slotId;

    if (s.status !== "booked") {
      div.addEventListener("click", () => selectSlot(s.slotId || s.id, div));
    }

    slotGrid.appendChild(div);
  });
}

function selectSlot(id, el) {
  selectedSlotId = id;
  selectedSlotText.innerText = id;
  document.querySelectorAll(".slot").forEach((d) => d.classList.remove("selected"));
  el.classList.add("selected");
}

async function handleConfirmBooking() {
  if (!currentUser) {
    alert("Not logged in.");
    return;
  }
  if (!selectedSlotId) {
    alert("Select a slot first.");
    return;
  }

  const vehicle = vehicleInput.value.trim();
  const duration = parseInt(durationInput.value, 10);

  if (!vehicle) {
    alert("Enter vehicle number.");
    return;
  }
  if (!duration || duration <= 0) {
    alert("Enter valid duration.");
    return;
  }

  try {
    await addDoc(collection(db, "bookings"), {
      userId: currentUser.uid,
      slotId: selectedSlotId,
      vehicleNumber: vehicle,
      duration,
      status: "booked",
      bookingTime: serverTimestamp()
    });

    await updateDoc(doc(db, "parking_slots", selectedSlotId), {
      status: "booked"
    });

    alert("Booking confirmed!");

    selectedSlotId = null;
    selectedSlotText.innerText = "None";
    vehicleInput.value = "";
    durationInput.value = "";

    await loadSlots();
  } catch (err) {
    console.error(err);
    alert("Booking failed: " + err.message);
  }
}
