import { auth, db } from "./firebase.js";
import { createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { doc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

export async function registerUser(name, email, phone, address, password) {
  if (!name || !email || !phone || !address || !password) {
    alert("Please fill all fields.");
    return;
  }

  try {
    const cred = await createUserWithEmailAndPassword(auth, email, password);

    await setDoc(doc(db, "users", cred.user.uid), {
      name,
      email,
      phone,
      address,
      createdAt: serverTimestamp()
    });

    alert("Registration successful!");
    window.location.href = "login.html";
  } catch (err) {
    alert("Registration failed: " + err.message);
  }
}
