import { auth, db } from "./firebase.js";
import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

import {
  collection,
  getDocs,
  doc,
  updateDoc,
  addDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

onAuthStateChanged(auth, (user) => {
  if (!user) window.location.href = "login.html";
  else loadSlots();
});

async function loadSlots() {
  const snap = await getDocs(collection(db, "parking_slots"));

  let available = 0;
  let occupied = 0;

  const zoneA = document.getElementById("slotsA");
  const zoneB = document.getElementById("slotsB");

  zoneA.innerHTML = "";
  zoneB.innerHTML = "";

  snap.forEach((docSnap) => {
    const s = docSnap.data();

    if (!s.slotId) return;

    const isAvailable = s.status === "available";
    if (isAvailable) available++; else occupied++;

    const card = document.createElement("div");
    card.className = "slot-card";

    card.innerHTML = `
      <div class="slot-id">${s.slotId}
        <span class="status-dot ${isAvailable ? "available-dot" : "occupied-dot"}"></span>
      </div>
      <p class="slot-price">₹5/hr</p>
      <button class="select-btn" ${!isAvailable ? "disabled" : ""}>Select</button>
    `;

    card.querySelector("button").addEventListener("click", () => {
      bookSlot(s.slotId);
    });

    if (s.slotId.startsWith("A")) zoneA.appendChild(card);
    else zoneB.appendChild(card);
  });

  document.getElementById("availableCount").innerText = available;
  document.getElementById("occupiedCount").innerText = occupied;
  document.getElementById("slotCount").innerText =
    `${available + occupied} spaces available • ${occupied} occupied`;
}

async function bookSlot(slotId) {
  let vehicle = prompt("Enter Your Vehicle Number:");
  if (!vehicle) return;

  await addDoc(collection(db, "bookings"), {
    slotId,
    vehicleNumber: vehicle,
    bookingTime: serverTimestamp(),
    status: "booked"
  });

  await updateDoc(doc(db, "parking_slots", slotId), {
    status: "booked"
  });

  alert("Booking Confirmed!");
  loadSlots();
}
