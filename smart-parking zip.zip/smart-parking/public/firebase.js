import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCcTLqw7XSBcf2AQYkC2PZjsE22ODw5abA",
  authDomain: "smart-parking-system-4939d.firebaseapp.com",
  projectId: "smart-parking-system-4939d",
  storageBucket: "smart-parking-system-4939d.appspot.com",
  messagingSenderId: "662654809021",
  appId: "1:662654809021:web:4cf9f48f450d0f1cc858d4",
  measurementId: "G-2MEW42W0S1"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
