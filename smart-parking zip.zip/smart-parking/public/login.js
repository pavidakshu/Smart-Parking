import { auth } from "./firebase.js";
import {
  signInWithEmailAndPassword,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

export async function loginUser(email, password) {
  if (!email || !password) {
    alert("Enter email and password.");
    return;
  }

  try {
    await signInWithEmailAndPassword(auth, email, password);
    console.log("LOGIN SUCCESS");

    // Redirect ONLY after login
    window.location.href = "locations.html";

  } catch (err) {
    alert("Login failed: " + err.message);
  }
}

// 🔥 VERY IMPORTANT
// Auto redirect ONLY when user is on login page
onAuthStateChanged(auth, (user) => {
  if (user && location.pathname.endsWith("login.html")) {
    window.location.href = "locations.html";
  }
});
